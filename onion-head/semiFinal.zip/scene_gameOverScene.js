class GameOverScene extends Phaser.Scene {
    constructor() {
        super("GameOverScene")
    }

    create() {
        this.add.text(345, 290, "YOU LOSE!", {
            fontSize: "32px",
            fill: "#000",
        });
        const playAgainButton = this.add.text(315, 390,
            "Click here to play again", {
            fontSize: "16px",
            fill: "#000",
        })
        .setInteractive()
        .on("pointerdown", () => {
            this.scene.stop("EndScene")
            this.scene.start("Level1")
            this.anims.resumeAll();
        })

    }
}